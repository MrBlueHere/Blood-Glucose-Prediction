# LaTeX template for theses at FIT CTU

## Current maintainers

* [Ondřej Guth](https://usermap.cvut.cz/profile/guthondr)
* [Eliška Šestáková](https://usermap.cvut.cz/profile/sestaeli)



[![build status](https://gitlab.fit.cvut.cz/theses-templates/FITthesis-LaTeX/badges/master/build.svg)](https://gitlab.fit.cvut.cz/theses-templates/FITthesis-LaTeX/commits/master)

